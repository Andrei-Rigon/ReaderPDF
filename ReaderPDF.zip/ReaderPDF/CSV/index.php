<?php
session_start();
include('../Function/ConvertMonth.php');
require 'CSV/PhpSpreadsheet-master/src/PhpSpreadsheet/autoloader.php';

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
    
//SetVariaveis Cabeçalho Geral
$MonthName; // A1 Check
$Wage = $_SESSION['Wage']; // A3 Check
$PeriodInicial = $_SESSION['DataInicial']; // E1 
$PeriodFinal = $_SESSION['DataFinal'];
//$Add = $_SESSION['']; // E3

//SetVariaveis Body Sicoob
//$Gastos = $_SESSION[''];  // B7 String
//$Legend = $_SESSION['']; // C7 String
//$PayString = $_SESSION['']; // D7 String
//$ReceiveString = $_SESSION['']; // E7 String
//$EspacoVazio = $_SESSION['']; // F7 Null
//$PayNumeric = $_SESSION['']; // G7 Numeric
//$ReceivNumeric = $_SESSION['']; // H7 Numeric
//$Transfer = $_SESSION['']; // I7 Numeric

// Escreve Dados
//$Teste = $_SESSION['Wage'];


$Planilha = new Spreadsheet(); // Cria o novo objeto de planilha
$CSV = $Planilha->getActiveSheet(); // Pega o primeiro arquivo da planilha (Planilha1)

$CSV->setcellValue('A1', 'Mês' . $MonthName); // Insere a variavel $MonthName na celula A1

$Writer = new xlsx($Planilha);
$Writer->save('File/financas.xlsx');







